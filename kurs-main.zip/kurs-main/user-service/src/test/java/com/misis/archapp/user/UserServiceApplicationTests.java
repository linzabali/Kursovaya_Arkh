package com.misis.archapp.user;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Disabled
@SpringBootTest
class UserServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
